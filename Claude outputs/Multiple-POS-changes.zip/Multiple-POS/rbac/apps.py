from django.apps import AppConfig


class RbacConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "rbac"
    verbose_name = "Roles & permissions"

    def ready(self):
        from . import signals
        signals.connect()
